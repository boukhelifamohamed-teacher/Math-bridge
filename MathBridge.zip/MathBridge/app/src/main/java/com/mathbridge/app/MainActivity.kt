package com.mathbridge.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private val siteUrl =
        "https://sites.google.com/view/math-bridge26/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9"
    private val facebookUrl = "https://www.facebook.com/share/g/1SG6dR4V6V/"

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host ?: ""
                return if (host.endsWith("google.com") || host.endsWith("googleusercontent.com")) {
                    false
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    true
                }
            }
        }
        webView.loadUrl(siteUrl)

        findViewById<View>(R.id.bar).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(facebookUrl)))
        }

        val splash = findViewById<View>(R.id.splash)
        Handler(Looper.getMainLooper()).postDelayed({
            splash.animate().alpha(0f).setDuration(500).withEndAction {
                splash.visibility = View.GONE
            }.start()
        }, 2500)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
