package com.mathbridge.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private val siteUrl =
        "https://sites.google.com/view/math-bridge26/%D8%A7%D9%84%D8%B5%D9%81%D8%AD%D8%A9-%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9"
    private val facebookUrl = "https://www.facebook.com/share/g/1SG6dR4V6V/"

    private lateinit var webView: WebView

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
        }
    }

    private fun isFacebook(uri: Uri): Boolean {
        val h = uri.host?.lowercase() ?: return false
        return h == "fb.com" || h == "fb.me" || h == "fb.watch" ||
            h.endsWith(".fb.com") || h.endsWith("facebook.com")
    }

    // يرجع true إذا فُتح الرابط خارج التطبيق (فيسبوك أو روابط الاتصال والبريد)
    private fun openedOutside(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") {
            openExternal(uri)
            return true
        }
        if (isFacebook(uri)) {
            openExternal(uri)
            return true
        }
        return false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.setSupportMultipleWindows(true)
        webView.settings.javaScriptCanOpenWindowsAutomatically = true

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return openedOutside(request.url)
            }
        }

        // الروابط التي تُفتح في "نافذة جديدة" تُحمَّل داخل التطبيق نفسه
        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                val temp = WebView(this@MainActivity)
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, request: WebResourceRequest): Boolean {
                        if (!openedOutside(request.url)) {
                            webView.loadUrl(request.url.toString())
                        }
                        return true
                    }
                }
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = temp
                resultMsg.sendToTarget()
                return true
            }
        }

        webView.loadUrl(siteUrl)

        findViewById<View>(R.id.bar).setOnClickListener {
            openExternal(Uri.parse(facebookUrl))
        }

        val splash = findViewById<View>(R.id.splash)
        Handler(Looper.getMainLooper()).postDelayed({
            splash.animate().alpha(0f).setDuration(500).withEndAction {
                splash.visibility = View.GONE
            }.start()
        }, 2500)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
